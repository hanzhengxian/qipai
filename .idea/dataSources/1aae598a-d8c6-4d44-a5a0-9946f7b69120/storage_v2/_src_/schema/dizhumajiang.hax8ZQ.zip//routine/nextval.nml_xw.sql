create function nextval(seq_name varchar(30))
  returns int
  comment '获取序列下一个值'
  BEGIN
  UPDATE nextval a
  SET a.current_value = (CASE
      WHEN LAST_INSERT_ID(a.current_value + a.increment) >= a.max_value THEN a.start_value ELSE LAST_INSERT_ID(a.current_value + a.increment)
    END)
  WHERE a.name = seq_name;
  RETURN LAST_INSERT_ID();
END;

